//
#include<iostream>
#include"Card.h"
#include"Deck.h"
using namespace std;

int main()
{
    Deck deck;

    Card c = deck.draw();
    Card p = deck.draw();
    cout << "The computer drew a: " << c.getName() << endl;
    cout << "The player drew a: " << p.getName() << endl;
    return 0;
}
