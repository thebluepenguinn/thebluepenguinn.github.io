//Card.cpp
//implementation of class cards
#include"Card.h"

Card::Card(int i)
{
    id = i;
}

string Card::getNumber() const 
{
    int cardNumber = id % 13 + 1;
    string cardString = to_string(cardNumber);
    if(cardNumber == 1)
    {  
        cardString = "Ace";
    }
    if(cardNumber == 11)
    {
        cardString = "Jack";
    }
    if(cardNumber == 12)
    {
        cardString = "Queen";
    }
    if(cardNumber == 13)
    {
        cardString = "King";
    }
    return cardString;
}

string Card::getSuit() const
{
    int suitNumber = id/13;
    string suit = "Clubs";
    if(suitNumber == 1)
    {
        suit = "Diamonds";
    }
    if(suitNumber == 2)
    {
        suit = "Hearts";
    }
    if(suitNumber == 3)
    {
        suit = "Spades";
    }
    return suit;
}

string Card::getName() const
{
    return getNumber() + " of " + getSuit();
}

int Card::getValue() const
{
    int value = id % 13 + 1;
    if (value > 10) value = 10;
    if (value == 1) value = 11; 
    return value;
}

int Card :: getBlackjackValue() const
{
    int value = getValue();
    return value;
}
