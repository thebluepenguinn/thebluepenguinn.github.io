// Deck.h
// Defines a class to hold a deck of Cards

#ifndef Deck_H
#define Deck_H
#include"Card.h"
#include <cstdlib>
class Deck
{
    private:
    Card card[52];
    int top;

    public: 
    Deck();
    void shuffle();
    Card draw();
};
#endif
