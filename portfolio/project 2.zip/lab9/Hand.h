#ifndef HAND_H
#define HAND_H

#include "Card.h"
#include <vector>

using namespace std;

class Hand 
{
    private:
    vector<Card> cards;

    public:
    void addCard(const Card& c);
    int getHandValue() const;
    void printHand(bool showAll) const; 
    void clear();
};

#endif // HAND_H


