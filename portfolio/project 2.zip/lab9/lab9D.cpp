// Blackjack.cpp
// ./Blackjack
#include "Deck.h"
#include "Hand.h"
#include <iostream>
#include <string>
using namespace std;

int main() {
    int playerMoney = 100;
    string playAgain;
    int bet;
    Deck deck;
                        
    cout << "*** Welcome to the casino ***" << endl;
    
    do {
        cout << "You have $" << playerMoney << ". Would you like to play Blackjack (y or n)? ";
         cin >> playAgain;

         if (playAgain != "y") break;

         do 
         {
            cout << "How much would you like to bet? ";
            cin >> bet;
            
            if (bet > playerMoney) 
            {
                cout << "You only have $" << playerMoney << ". ";
            }
         } 
         while (bet < 1 || bet > playerMoney);
         
         deck.shuffle(); 
                 
         Hand playerHand, dealerHand;

         playerHand.addCard(deck.draw());
         playerHand.addCard(deck.draw());
         dealerHand.addCard(deck.draw());
         dealerHand.addCard(deck.draw());
                                                         
         cout << "\nYour hand: " << endl;
         playerHand.printHand(true);
         cout << "\nYour hand is worth " << playerHand.getHandValue() << ".\n" << endl;

         cout << "Dealer hand: " << std::endl;
         dealerHand.printHand(false);

         string choice;
         while (playerHand.getHandValue() < 21) 
         {
            cout << "Would you like to (h)it or (s)tay? ";
            cin >> choice;
            if (choice == "s") break;
            playerHand.addCard(deck.draw());
            cout << "\nYour hand: " << endl;
            playerHand.printHand(true);
            cout << "\nYour hand is worth " << playerHand.getHandValue() << ".\n" << endl;
         }
                 while (dealerHand.getHandValue() < 17) 
                 {
                    dealerHand.addCard(deck.draw());
                 }
                 
                 cout << "Dealer hand: " << endl;
                 dealerHand.printHand(true);
                 cout << "The Dealer hand is worth " << dealerHand.getHandValue() << "\n" << endl;

                 if (dealerHand.getHandValue() > 21 || playerHand.getHandValue() > dealerHand.getHandValue()) 
                 {
                    cout << "You win!!!" << std::endl;
                    playerMoney += bet;
                 }
                 else if (playerHand.getHandValue() > 21 || dealerHand.getHandValue() >= playerHand.getHandValue()) 
                 {
                    cout << "Dealer wins." << endl;
                    playerMoney -= bet;
                 }
    cout << "You have $" << playerMoney << ". Would you like to play Blackjack (y or n)? ";
    cin >> playAgain;
    } 
    while (playerMoney > 0 && playAgain == "y");
        
    return 0;
}
