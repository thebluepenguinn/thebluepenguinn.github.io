#include "Hand.h"
#include <iostream>
using namespace std;

void Hand::addCard(const Card& c) 
{
    cards.push_back(c);
}

int Hand::getHandValue() const 
{ 
    int value = 0;
    int aces = 0;
    for (const auto& card : cards) 
    {
        int cardValue = card.getBlackjackValue();
        value += cardValue;
        if (cardValue == 11) ++aces; 
    }       
    while (value > 21 && aces > 0) 
    {
        value -= 10;
        --aces;
    }
    return value;
}

void Hand::printHand(bool showAll) const 
{
    if (!showAll) 
    {
        cout << "HIDDEN" << endl;
        for (size_t i = 1; i < cards.size(); ++i) 
        {
            cout << cards[i].getName() << std::endl;
        }
    } 
    else 
    {
        for (const auto& card : cards) 
        {
            cout << card.getName() << endl;
        }
    }
}

void Hand::clear() 
{
    cards.clear();
}

