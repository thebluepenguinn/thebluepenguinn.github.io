//
// DeckTest.cpp
// Tests the Deck class
#include"Card.h"
#include"Deck.h"
#include <cstdlib>
using namespace std;
Deck::Deck()
{
    for(int i = 0; i < 52; i++)
    {
        card[i] = Card(i);
    }
    shuffle();
}

void Deck::shuffle()
{
    srand(time(0));
    for
        (int i = 0; i < 52; i++)
        {
            int swapCard = rand() % 52;
            Card temp = card[i];
            card[i] = card[swapCard];
            card[swapCard] = temp;
         }
     top = 0;
}

Card Deck::draw()
{
    top++;
    return card[top-1];
}
