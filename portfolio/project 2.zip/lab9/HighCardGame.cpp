// HighCardGame.cpp
#include "Card.h"
#include "Deck.h"
#include <iostream>
#include <string>
#include <algorithm>
using namespace std;


class Hand 
{
    public:
    static const int size = 3;
    Card cards[size];
};


int main() 
{
    int playerMoney = 100;
    string playAgain;
    int bet;
    Deck deck;


do
{
    cout << "You have $" << playerMoney << ". Would you like to play (yes/no): ";    cin >> playAgain;

    if(playAgain == "yes" && playerMoney > 0)
    {
        do
        {
            cout << "Place yout bet (1-10): ";
            cin >> bet; 
        }
        while(bet < 1 || bet > 10 || bet > playerMoney);

        deck.shuffle();

        Hand playerHand;
        Hand computerHand;

        
        for(int i = 0; i < Hand::size; ++i)
        {
            playerHand.cards[i] = deck.draw();
            computerHand.cards[i] = deck.draw();
        }

        sort(playerHand.cards, playerHand.cards + Hand::size);
        sort(computerHand.cards, computerHand.cards + Hand::size);

        cout << "Your cards: ";
        for(int i = 0; i < Hand::size; ++i)
        {
           cout << playerHand.cards[i].getName() << " " << endl;
        }
           cout << "Computer's cards: ";
        for(int i = 0; i< Hand::size; ++i)
        {
            cout << computerHand.cards[i].getName() << " " << endl;
        }

       int playerHighestValue = playerHand.cards[Hand::size-1].getValue();
       int computerHighestValue = computerHand.cards[Hand::size-1].getValue();

        if(playerHighestValue > computerHighestValue)
        {
            cout << "\nYou win!" << endl;
            playerMoney += bet;
        }
        else if(computerHighestValue > playerHighestValue )
        {
            cout << "\nThe computer wins!" << endl; 
            playerMoney -= bet;
        }
        else 
        {
            cout << "\nIt's a tie" << endl;
        }
    }
        else
        {
            cout << "Maybe next time!" << endl;
            break;
        }
    }
    while(playerMoney > 0 && (playAgain == "yes"));
    cout << "You left with $" << playerMoney << endl; 
    return 0;
}


