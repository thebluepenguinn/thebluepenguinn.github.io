//Card.h
//objects of this class represent a single playing card
#ifndef Card_H
#define Card_H
#include <iostream>
#include<string>
using namespace std;

class Card
{
    private:
    int id;

    public:
    Card(int i = 0);
    string getNumber() const;
    string getSuit() const;
    string getName() const;
    int getValue() const;
    int getBlackjackValue() const;
};
#endif
